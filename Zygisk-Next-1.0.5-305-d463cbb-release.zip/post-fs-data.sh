#!/system/bin/sh

MODDIR=${0%/*}

export TMP_PATH=/sbin/zygisk
[ -d /sbin ] || export TMP_PATH=/debug_ramdisk/zygisk

create_sys_perm() {
  mkdir -p $1
  chmod 555 $1
  chcon u:object_r:system_file:s0 $1
}

create_sys_perm $TMP_PATH

if [ "$ZYGISK_ENABLED" ]; then
  cp $MODDIR/module.prop $TMP_PATH/module.prop
  sed 's/description=/description=\['$(echo -e '\xE2\x9D\x8C')' Please disable Magisk'"'"'s zygisk and reboot!\]/g' \
    $MODDIR/module.prop > $TMP_PATH/module.prop
  mount --bind $TMP_PATH/module.prop  $MODDIR/module.prop
  exit 0
fi

cd "$MODDIR"

if [ "$(which magisk)" ]; then
  for file in ../*; do
    if [ -d "$file" ] && [ -d "$file/zygisk" ] && ! [ -f "$file/disable" ]; then
      if [ -f "$file/post-fs-data.sh" ]; then
        cd "$file"
        log -p i -t "zygisk-sh" "Manually trigger post-fs-data.sh for $file"
        sh "$(realpath ./post-fs-data.sh)"
        cd "$MODDIR"
      fi
    fi
  done
fi

if [ -f $MODDIR/lib64/libzygisk.so ];then
  create_sys_perm $TMP_PATH/lib64
  cp $MODDIR/lib64/libzygisk.so $TMP_PATH/lib64/libzygisk.so
  chcon u:object_r:system_file:s0 $TMP_PATH/lib64/libzygisk.so
fi

if [ -f $MODDIR/lib/libzygisk.so ];then
  create_sys_perm $TMP_PATH/lib
  cp $MODDIR/lib/libzygisk.so $TMP_PATH/lib/libzygisk.so
  chcon u:object_r:system_file:s0 $TMP_PATH/lib/libzygisk.so
fi

cp $MODDIR/lib64/libpayload.so $TMP_PATH/libpayload.so
chmod 555 $TMP_PATH/libpayload.so
chcon u:object_r:magisk_file:s0 $TMP_PATH/libpayload.so

mkdir -p /data/adb/zygisksu
[ -f /data/adb/zygisksu/znctx ] && mv /data/adb/zygisksu/znctx /data/adb/zygisksu/znctx.old
[ -f /data/adb/zygisksu/modules_info ] && mv /data/adb/zygisksu/modules_info /data/adb/zygisksu/modules_info.old

if [ -d /data/adb/ksu/log ]; then
  [ -f /data/adb/ksu/log/znctx ] && mv /data/adb/ksu/log/znctx /data/adb/ksu/log/znctx.old
  [ -f /data/adb/ksu/log/modules_info ] && mv /data/adb/ksu/log/modules_info /data/adb/ksu/log/modules_info.old
fi

[ "$DEBUG" = true ] && export RUST_BACKTRACE=1
[ -f /data/adb/zygisksu/klog ] && [ "1" == $(cat /data/adb/zygisksu/klog) ] && export KLOG_ENABLED=1
./bin/zygiskd64 daemon

if [ -d /data/adb/ksu/log ]; then
  cp /data/adb/zygisksu/znctx /data/adb/ksu/log/znctx
  cp /data/adb/zygisksu/modules_info /data/adb/ksu/log/modules_info
fi
