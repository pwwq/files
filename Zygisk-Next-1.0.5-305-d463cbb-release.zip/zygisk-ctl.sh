MODDIR=${0%/*}/..

TMP_PATH=/sbin
[ -d /sbin ] || export TMP_PATH=/debug_ramdisk

export TMP_PATH=$TMP_PATH/zygisk

exec $MODDIR/bin/zygiskd64 ctl $*
