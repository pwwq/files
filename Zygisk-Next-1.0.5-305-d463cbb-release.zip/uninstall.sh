rm -rf /data/adb/zygisksu
