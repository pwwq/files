DATADIR="/data/adb/sfm"

rm_data()
{
  rm -rf ${DATADIR}
}

rm_data