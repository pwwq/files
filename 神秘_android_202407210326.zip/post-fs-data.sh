#!/bin/sh
MODDIR=${0%/*}

touch ${MODDIR}/start