#节点储存目录
nodeStoreDir='../全局节点'

#清空 [全局节点] 、 [海内节点] 和 [全局UDP节点] 目录(true开启)
clearNodeDir='true'

#节点分享链接(一行一个链接)
nodeLinks='
vmess://b3d034f8-6a91-4995-a988-93ea73f7a5d4@2162e620-3315-61b3-d55d-9bf95b93ae40.cnnic.rip:20777?encryption=auto&host=tms.dingtalk.com&path=%2F&type=ws#%E7%BC%85%E7%94%B8%2001%20%20%7C%20ws
'
#mux开关(true开启)
mux='false'

#免流Host, 如果不设置则使用节点自带的
repHost=''

#path, 如果不设置则使用节点自带的
repPath=''


cd "${0%/*}"
sh ../Core/downloadCore.sh "$repHost" 'MLBox' 'Usgae'
echo "节点保存目录为: $PWD/$nodeStoreDir"
echo '节点文件(.ini结尾) 需要复制到 全局节点 或 海内节点 文件夹才可以用'
alias 'MLBox=../Core/MLBox'
mkdir "$nodeStoreDir" 2>/dev/null
[ "$clearNodeDir" = 'true' ] && rm -f ../海内节点/*.ini ../全局节点/*.ini ../全局UDP节点/*.ini
i=1
for v2link in $nodeLinks; do
	v2msg=`MLBox -v2Link="$v2link"`
	eval "$v2msg"
	echo "$ps" | grep -q '/' && ps="${ps//\//\\}"
	filePath="${nodeStoreDir:=$PWD}/${i}_${ps// /_}.ini"
	echo "$v2msg" >>"$filePath"
	if [ -n "$repHost" ]; then
		host="$repHost"
		sni="$repHost"
	fi
	if [ -n "$repPath" ]; then
		path="$repPath"
	fi
	cat >"$filePath" <<-EOF
$v2msg
mux='$mux'
#host/sni/path以下方的值为准
host='$host'
sni='${sni:-$host}'
path='${path}'
	EOF
	echo -E "第$i个节点: ${ps}, 已写入文件: ${i}_${ps// /_}.ini"
	for v in ${v2msg// /_}; do
		unset "${v%=*}"
	done
	i=$((i + 1))
done
