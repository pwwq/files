dataDir="/data/adb/sfm"

RmData() {
    rm -rf ${dataDir}
}

RmData