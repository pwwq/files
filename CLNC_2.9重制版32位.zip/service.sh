# 开机之后执行
#!/system/bin/sh
# 不要假设您的模块将位于何处。
# 如果您需要知道此脚本和模块的放置位置，请使用$MODDIR
# 这将确保您的模块仍能正常工作
# 即使Magisk将来更改其挂载点
MODDIR=${0%/*}
#检测安装状态
mkdir -p /data/clnc &>/dev/null
[ -d /data/clnc ] || cp -af ${0%/*}/clnc /data/
# 开启防跳
sleep 8
svc data disable
sleep 9
/data/clnc/开启.sh > /dev/null 2>&1
