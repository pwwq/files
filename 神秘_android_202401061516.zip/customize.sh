SKIPUNZIP=1

if [ "${ARCH}" != "arm64" ] ; then
  abort "- 不支持的架构，本模块只支持 arm64 架构的设备"
fi

unzip -o "${ZIPFILE}" -x 'META-INF/*' -d ${MODPATH} >&2
set_perm_recursive ${MODPATH} 0 0 7777 7777

DATADIR="/data/adb/sfm"
TIMESTAMP=$(date "+%Y%m%d%H%M")
PACKAGELIST="/data/system/packages.list"
TERMUXPKGNAME="com.termux"
MAGISKBOX="/data/adb/magisk/busybox"
KSUBOX="/data/adb/ksu/bin/busybox"
BOXPATH="busybox"
FIRSTINSTALL=1

if [ -f ${MAGISKBOX} ] ; then
  BOXPATH="${MAGISKBOX}"
elif [ -f ${KSUBOX} ] ; then
  BOXPATH="${KSUBOX}"
else
  abort "- 未找到 busybox，请检查你的系统是否有 busybox 存在！"
fi

if [ "$(cat ${PACKAGELIST} | grep ${TERMUXPKGNAME})" = "" ] ; then
  ui_print "- 未安装 termux，将为您自动跳转下载页"
  am start -a android.intent.action.VIEW -d "https://f-droid.org/repo/com.termux_118.apk"
  abort
fi

export PATH=/data/data/com.termux/files/usr/bin:/data/data/com.termux/files/usr/bin/applets:$PATH
export LD_LIBRARY_PATH=/data/data/com.termux/files/usr/lib

if [ $(dpkg -l | grep ^ii | grep nodejs) == "" ] ; then
  abort "- 未检测到 termux node 环境，请安装后再刷写"
elif [ $(dpkg -l | grep ^ii | grep aapt) == "" ] ; then
  abort "- 未检测到 termux aapt 环境，请安装后再刷写"
fi

NODESTATUS=$(node -v > /dev/null 2>&1; echo $?)
AAPTSTATUS=$(aapt v > /dev/null 2>&1; echo $?)

if [ "${NODESTATUS}" != "" ] && [ "${NODESTATUS}" != "0" ] ; then
  abort "- node 环境损坏"
elif [ "${AAPTSTATUS}" != "" ] && [ "${AAPTSTATUS}" != "0" ] ; then
  abort "- aapt 环境损坏"
fi

DEFAULTSIGNAL=$(${BOXPATH} timeout 0.00001s ${MODPATH}/keycheck; echo $?)

install_app()
{
  local maho="webapp.shenmi"

  if [ "$(cat ${PACKAGELIST} | grep ${maho})" = "" ] ; then
    
    ui_print "- 未安装神秘 app，请根据提示按下相应按键，你将有 10s 的反应时间"
    ui_print "- 音量下/音量 -：安装神秘 app（默认响应）"
    ui_print "- 音量上/音量 +：跳过"

    local SIGNAL=$(${BOXPATH} timeout 10s ${MODPATH}/keycheck; echo $?)

    if [ "${SIGNAL}" = "41" ] || [ "${SIGNAL}" = "${DEFAULTSIGNAL}" ] ; then
      ui_print "- 安装神秘 app"
      pm install ${MODPATH}/base.apk
      if [ "$(cat ${PACKAGELIST} | grep ${maho})" = "" ] ; then
        ui_print "- 安装失败，将在下次系统启动时自动安装"
      else
        rm -rf ${MODPATH}/base.apk
      fi
    else
      ui_print "- 跳过"
      rm -rf ${MODPATH}/base.apk
    fi
  else
    ui_print "- 已安装神秘 app，将自动清除 app 缓存"
    pm clear ${maho}
    rm -rf ${MODPATH}/base.apk
  fi
}

kill_node()
{
  local nodePid=$(echo "$1" | awk -F' ' '{print $7}' | awk -F'/' '{print $1}' )
  kill -9 ${nodePid}
}

start_maho()
{
  ${MODPATH}/service.sh
  sleep 3
  if [ "$(netstat -tunlp | grep 23333 | grep node )" != "" ] ; then
    ui_print "- 启动完成，请访问面板/app 获得帮助"
  else
    ui_print "- 启动失败，请尝试重启设备或检查日志"
  fi
}

start_process()
{
  touch ${MODPATH}/install
  local key=$(${BUSYBOX} awk '/authorizationKey/{print $2}' /data/adb/sfm/src/config.hjson)
  local mahoStatus=$(netstat -tunlp | grep 23333 | grep node )
  if [ "${FIRSTINSTALL}" = "1" ] ; then
    ui_print "- 正在启动神秘"
    if [ "${mahoStatus}" != "" ] ; then
      kill_node "${mahoStatus}"
    fi
  else
    if [ "$(ps -el | grep singBox)" = "" ] ; then
      ui_print "- 八音盒未在唱歌，将直接更新"
      kill_node
      start_maho
    else
      ui_print "- 八音盒正在在唱歌，请根据提示按下相应按键，你将有 10s 的反应时间"
      ui_print "- 音量下/音量 -：立即更新神秘（默认响应）"
      ui_print "- 音量上/音量 +：下次启动时更新"

      local SIGNAL=$(${BOXPATH} timeout 10s ${MODPATH}/keycheck; echo $?)

      if [ "${SIGNAL}" = "41" ] || [ "${SIGNAL}" = "${DEFAULTSIGNAL}" ] ; then
        ui_print "- 立即更新神秘"
        if [ "${mahoStatus}" != "" ] ; then
          curl "127.0.0.1:23333/api/kernel" -H "authorization: ${key}" -H "Content-Type: application/json" -d '{"method":"stop"}' > /dev/null 2>&1
          kill_node "${mahoStatus}"
        else
          killall -9 singBox
        fi
        ui_print "- 已关闭八音盒和神秘，现在开始重新启动"
        start_maho
      else
        ui_print "- 下次启动时更新"
      fi
    fi
  fi
}

if [ -d ${DATADIR} ] ; then
  ui_print "- 检测到数据目录，开始增量更新"
  FIRSTINSTALL=0
  MODULEPATH=$(cat ${DATADIR}/src/modulePath)
  PROPPATH="${MODULEPATH}/module.prop"
  MODULEVERSION=$(cat ${PROPPATH} | grep versionCode | awk -F= '{print $2}' )

  if [ ${MODULEVERSION} -lt 5 ]; then
    abort "- 版本太低，请先升级到 202303042355 再刷写此版本"
  fi

  mkdir -p ${DATADIR}.old/${TIMESTAMP}/
  mv -f $(ls ${DATADIR} | grep -v "singBox" | awk '{print"/data/adb/sfm/"$0}') ${DATADIR}.old/${TIMESTAMP}/
  mv -f ${MODPATH}/sfm/singBox ${DATADIR}/singBox.new
  cp -rf ${MODPATH}/sfm/* ${DATADIR}/
  cp -rf ${DATADIR}.old/${TIMESTAMP}/box.json ${DATADIR}/box.json
  cp -rf ${DATADIR}.old/${TIMESTAMP}/ProxyProviders/*.json ${DATADIR}/ProxyProviders/
  cp -rf ${DATADIR}.old/${TIMESTAMP}/RuleProviders/*.json ${DATADIR}/RuleProviders/
  cp -rf ${DATADIR}.old/${TIMESTAMP}/RuleProviders/*.srs ${DATADIR}/RuleProviders/
  rm -rf ${DATADIR}/Dashboard/*
  cp -rf ${DATADIR}.old/${TIMESTAMP}/Dashboard/* ${DATADIR}/Dashboard/
  cp -rf ${DATADIR}.old/${TIMESTAMP}/src/FileProviders/* ${DATADIR}/src/FileProviders/
  cp -f ${DATADIR}.old/${TIMESTAMP}/src/geosite.db ${DATADIR}/src/geosite.db
  cp -f ${DATADIR}.old/${TIMESTAMP}/src/geosite.db.new ${DATADIR}/src/geosite.db.new
  cp -f ${DATADIR}.old/${TIMESTAMP}/src/geoip.db ${DATADIR}/src/geoip.db
  cp -f ${DATADIR}.old/${TIMESTAMP}/src/geoip.db.new ${DATADIR}/src/geoip.db.new
  cp -f ${DATADIR}.old/${TIMESTAMP}/src/cache.db ${DATADIR}/src/cache.db
  cp -f ${DATADIR}.old/${TIMESTAMP}/src/config.hjson ${DATADIR}/src/config.hjson
  cp -f ${DATADIR}.old/${TIMESTAMP}/src/baseConfig.hjson ${DATADIR}/src/baseConfig.hjson
  cp -f ${DATADIR}.old/${TIMESTAMP}/src/appLabels.json ${DATADIR}/src/appLabels.json
else
  ui_print "- 未检测到数据目录，开始全量安装"
  mkdir -p ${DATADIR}
  cp -rf ${MODPATH}/sfm/* ${DATADIR}/
fi

if [ ! -f ${DATADIR}/src/appLabels.json ] ; then
  ui_print "- 未检测到应用名缓存，现在开始生成"
  node ${MODPATH}/handle
fi

install_app

ui_print "- 开始设置环境权限"
set_perm_recursive ${DATADIR} 0 0 7777 7777

start_process

ui_print "- 开始清理环境"

rm -rf ${MODPATH}/sfm
rm -rf ${MODPATH}/keycheck
rm -rf ${MODPATH}/handle